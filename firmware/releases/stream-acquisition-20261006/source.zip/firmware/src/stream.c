#include "ld2450_stream.h"
#include "radar_wire.h"
#include <string.h>

#define ABORT_RESERVE 40u
static void le16(uint8_t *p, uint16_t v) { p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static void le32(uint8_t *p, uint32_t v) { le16(p,(uint16_t)v); le16(p+2,(uint16_t)(v>>16)); }
static int32_t signed_be16(const uint8_t *p)
{
    uint32_t v=((uint32_t)p[0]<<8)|p[1];
    return v & 0x8000u ? (int32_t)v-65536 : (int32_t)v;
}
uint32_t ld_stream_crc32(const uint8_t *data, size_t size)
{
    uint32_t crc=0xffffffffu;
    size_t n; unsigned b;
    for (n=0;n<size;++n) {
        crc ^= data[n];
        for (b=0;b<8;++b) crc=(crc>>1)^((0u-(crc&1u))&0xedb88320u);
    }
    return crc^0xffffffffu;
}
static uint32_t residual(const uint8_t *a, const uint8_t *b)
{
    int32_t d=signed_be16(a)-signed_be16(b);
    return d<0 ? (uint32_t)(-2*d-1) : (uint32_t)(2*d);
}
size_t ld_stream_encode(const uint8_t *r, const uint8_t *prev, uint8_t *out, size_t cap)
{
    size_t block, j, pos=9, packed_size=0;
    unsigned width, bit;
    uint8_t widths[32];
    if (!r || !out || cap<LD_STREAM_PAYLOAD_MAX) return 0;
    if (prev) {
        for (block=0;block<32;++block) {
            uint32_t maximum=0;
            for (j=0;j<32;++j) {
                size_t at=2*(block*32+j);
                uint32_t z=residual(r+4+at,prev+at);
                if (z>maximum) maximum=z;
            }
            width=0;
            while (maximum) { ++width; maximum>>=1; }
            widths[block]=(uint8_t)width;
            packed_size+=1+4*width;
        }
    }
    out[0]=(uint8_t)(prev && packed_size<2048);
    memcpy(out+1,r,4); memcpy(out+5,r+2052,4);
    if (!out[0]) { memcpy(out+9,r+4,2048); return 2057; }
    for (block=0;block<32;++block) {
        size_t base;
        width=widths[block]; out[pos++]=(uint8_t)width; base=pos;
        memset(out+base,0,4*width);
        for (j=0;j<32;++j) {
            size_t at=2*(block*32+j);
            uint32_t z=residual(r+4+at,prev+at);
            for (bit=0;bit<width;++bit) {
                size_t index=j*width+bit;
                out[base+index/8] |= (uint8_t)(((z>>(width-1-bit))&1u)<<(7-index%8));
            }
        }
        pos+=4*width;
    }
    return pos;
}
static void enqueue(struct ld_stream *s, const uint8_t *p, size_t size)
{
    size_t tail=(s->head+s->used)%s->capacity;
    size_t first=s->capacity-tail;
    if (first>size) first=size;
    memcpy(s->queue+tail,p,first); memcpy(s->queue,p+first,size-first);
    s->used+=size;
    if (s->used>s->stats.queue_peak) s->stats.queue_peak=(uint32_t)s->used;
}
/* Payload already in scratch+32; every message is enqueued atomically. */
static void message(struct ld_stream *s, uint8_t type, uint8_t lane,
                    uint16_t chirp, uint32_t time, size_t payload, uint32_t raw_crc)
{
    uint8_t *p=s->scratch;
    memcpy(p,"LDF1",4); p[4]=1; p[5]=type; p[6]=(uint8_t)(type==2); p[7]=lane;
    le16(p+8,(uint16_t)payload); le16(p+10,chirp);
    le32(p+12,s->sequence++); le32(p+16,s->frame); le32(p+20,time);
    le32(p+24,raw_crc); le32(p+28,ld_stream_crc32(p,28));
    le32(p+32+payload,ld_stream_crc32(p+32,payload));
    enqueue(s,p,36+payload);
}
int ld_stream_init(struct ld_stream *s, uint8_t *queue, size_t capacity, const uint8_t *config)
{
    if (!s || !queue || !config || capacity<LD_STREAM_MESSAGE_MAX+ABORT_RESERVE ||
        capacity>65535u) return -1;
    memset(s,0,sizeof(*s)); s->queue=queue; s->capacity=capacity;
    memcpy(s->config_sha256,config,32); return 0;
}
void ld_stream_abort(struct ld_stream *s, uint32_t reason, uint32_t time)
{
    if (!s || !s->active) return;
    s->active=0; ++s->stats.frames_rejected;
    le32(s->scratch+32,reason);
    message(s,4,255,65535,time,4,0); /* Reserved even at maximum backlog. */
}
int ld_stream_begin(struct ld_stream *s, uint32_t frame, uint32_t time)
{
    uint8_t *p;
    if (!s || !s->queue) return -1;
    if (s->active) ld_stream_abort(s,1,time); /* Missing prior frame tail. */
    if (s->used) { ++s->stats.frames_skipped; return 0; }
    s->frame=frame; s->active=1; s->next_chirp[0]=s->next_chirp[1]=0;
    p=s->scratch+32; memcpy(p,s->config_sha256,32);
    le32(p+32,s->stats.frames_skipped); le32(p+36,s->stats.frames_rejected);
    le32(p+40,s->stats.queue_peak); le16(p+44,512); le16(p+46,64);
    p[48]=2; p[49]=1; le16(p+50,0);
    message(s,1,255,65535,time,52,0); return 1;
}
int ld_stream_record(struct ld_stream *s, const uint8_t *r, size_t size, uint32_t time)
{
    struct radar_record decoded;
    size_t encoded;
    uint8_t lane;
    if (!s || !s->active) return 0;
    if (size!=2056 || radar_record_decode(r,size,&decoded)!=RADAR_RECORD_VALID ||
        decoded.declared_pairs!=512 || decoded.chirp>=64 ||
        decoded.chirp!=s->next_chirp[decoded.rx_index]) {
        ++s->stats.invalid_records; ld_stream_abort(s,2,time); return -1;
    }
    lane=decoded.rx_index;
    encoded=ld_stream_encode(r,s->next_chirp[lane] ? s->previous[lane] : NULL,
                            s->scratch+32,LD_STREAM_PAYLOAD_MAX);
    if (encoded+36+ABORT_RESERVE>s->capacity-s->used) {
        ++s->stats.queue_overflows; ld_stream_abort(s,3,time); return -1;
    }
    if (s->scratch[32]) ++s->stats.compressed_records; else ++s->stats.raw_records;
    message(s,2,lane,decoded.chirp,time,encoded,ld_stream_crc32(r,size));
    memcpy(s->previous[lane],r+4,2048); ++s->next_chirp[lane];
    if (s->next_chirp[0]==64 && s->next_chirp[1]==64) {
        message(s,3,255,65535,time,0,0);
        s->active=0; s->pending_complete=1; ++s->stats.frames_completed;
    }
    return 1;
}
int ld_stream_pump(struct ld_stream *s, ld_stream_write_fn write, void *context, size_t budget)
{
    size_t count; int accepted;
    if (!s || !write || !s->queue) return -1;
    if (!s->used || !budget) return 0;
    count=s->capacity-s->head;
    if (count>s->used) count=s->used;
    if (count>budget) count=budget;
    accepted=write(context,s->queue+s->head,count);
    if (accepted<0 || (size_t)accepted>count) {
        ++s->stats.transport_errors;
        if (s->active || s->pending_complete) ++s->stats.frames_rejected;
        s->active=0; s->pending_complete=0; s->head=0; s->used=0;
        /* Bytes already delivered may be a prefix: host resyncs on valid BEGIN. */
        return -1;
    }
    s->head=(s->head+(size_t)accepted)%s->capacity; s->used-=(size_t)accepted;
    if (!s->used) s->pending_complete=0;
    return accepted;
}
