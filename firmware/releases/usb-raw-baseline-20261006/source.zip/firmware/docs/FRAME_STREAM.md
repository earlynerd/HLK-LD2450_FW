# Lossless frame stream application

2026-10-06 afternoon: native USB is wired and enumerates as COM30, VID/PID
`4C4A:4155`, serial `LD2450-STREAM-01`. The current installed application is
the **raw USB-only diagnostic**, with the radar off. It transfers deterministic
synthetic records with compression disabled and pauses production at its
bounded queue limit. It does not test real radar acquisition.

The ten-second raw test delivered 7,294,976 wire bytes (~729 kB/s), including
27 complete paired frames whose 7,105,536 reconstructed bytes match the known
pattern exactly. No corruption occurred between the initial DTR-transition
prefix and incomplete capture tail. A three-second reader pause caused a
damaged/incomplete frame to be rejected, followed by ten exact complete frames;
reopening yielded another eleven exact frames. This establishes recovery, not
lossless host-stall behavior or physical unplug/replug qualification.

Raw diagnostic UFW SHA-256:
`4c7ef325f5ea3427ca6942030c990507f40bc470eaeffb48ffc16f625d294361`.
Preserved image/source: `firmware/releases/usb-raw-baseline-20261006/`.
Evidence: `output/stream_bench/usb_raw_bench_capture/`,
`usb_raw_bench_decoded/`, `usb_raw_stall*/`, and `usb_raw_reopen*/`.

The latest compressed radar image has **zero DMA overruns** in its three-second
USB capture and delivers valid messages, but its 48 KiB queue fills before any
complete frame reaches the host. Seventeen frames were explicitly rejected;
no incomplete frame was published. Its preserved build is
`firmware/build/usb-ram-crc/` (UFW SHA-256
`237ac75d42db5651bf1dcdc6040579a4777d14dacfc26b03a79b75a89e69879c`).
The next investigation is USB draining during record processing, with measured
queue occupancy and CPU/transport budgets. Increasing buffering alone is not
yet justified by measured physical memory headroom.

## Earlier acquisition-only reference

The acquisition-only bench run lasted 10.584937 seconds on the local timer:
7,536 valid records per lane, 117 complete paired 64-chirp frames, zero corrupt
records, sequence errors, timeouts or DMA overruns. Peak pending DMA backlog
was one record; maximum record processing time was 264 microseconds. USB was
absent, so all 118 observed frame starts intentionally skipped export. These
timings exclude encoding and USB load and do not qualify sustained export.
Evidence: [quiet-start run](../../output/stream_bench/quiet_start/result.json)
and [PA9 report](../../output/stream_bench/quiet_start/pa9.txt).

Flashed two-wire UFW SHA-256:
`388a98cf4c637a0d8863df2fedb7c248b77d027016525d1f74104075c9e0c8c4`.
The exact image, ELF, manifests and source snapshot are preserved in
`firmware/releases/stream-acquisition-20261006/`. Same-image updater reentry
passed from both stopped and running acquisition; the final run restarted
the application without issuing the stop command. USB had not yet been wired
at that milestone; the current USB results above supersede that limitation.

## Run the checks

From the `HLK-LD2450_FW` project root:

```powershell
python firmware/tools/test_host.py
python firmware/tools/build_br23.py --out firmware/build/stream-component
python firmware/tools/build_image.py --application stream
python firmware/tools/build_image.py --application usb-bench
python firmware/tools/build_image.py --application usb-bench --raw-usb-bench --out firmware/build/usb-raw-next
python firmware/tools/patch_stock_uart_loader.py --input firmware/build/stream/update.ufw --out firmware/build/stream/update-two-wire.ufw
```

CTest runs thirteen suites, including raw-only encoding, acquisition, the actual USB adapter with
mocked registers, nonblocking updater polling, and twelve C-to-Python
interoperability cases. Another 34 Python tests cover existing tools. The real
16-chirp startup fixtures reconstruct byte-for-byte and retain
their source hashes in `firmware/tests/fixtures/dual_lane_startup/manifest.json`.
Their codec payloads total 35,332 bytes from 65,792 bytes (53.7%), including
original record framing and codec overhead, excluding LDF1 transfer envelopes.
These are not complete frames or a worst-case compression guarantee. Separate
synthetic paired 64-chirp frames test completion. The 16-chirp stream test ends
with ABORT and must publish no complete frame.

Checks cover int16 extremes and 17-bit deltas, raw fallback, zero-width blocks,
USB-sized and arbitrary byte splits, queue wrapping, partial writes, stalls,
overflow, disconnect, missing/duplicate/reordered chirps, truncation, bad
lengths, header/payload/raw CRCs, radar checksums and recovery at a new BEGIN.

For the installed raw diagnostic, open COM30 with DTR asserted:

```powershell
python firmware/tools/frame_stream.py --port COM30 --seconds 10 --out output/usb-raw-next
python firmware/tools/verify_usb_bench.py output/usb-raw-next
```

`--raw-usb-bench` is accepted only with `--application usb-bench`. Its
configuration identity explicitly labels synthetic, paced, raw-only encoding.
The LDF1 wire format is unchanged. Every sample value is `17*index+chirp+lane`;
the independent verifier compares both full reconstructed lane files.

The speed fixes preserve the format: byte-table CRC, byte-oriented packing,
one residual calculation per sample using a 32-value scratch block, and `-O2`
for stream/acquisition/radar parsing. Stream images place the CRC routine and
1 KiB lookup table in startup-copied internal RAM. CPU configuration and live
registers agree: `CLK_CON0=0x1c3`, `CLK_CON2=0xc53`, `SYS_DIV=0x400` select the
480 MHz PLL divided by two, HSB divide one and LSB divide five. Runtime
`clk_get("sys")` reports 240 MHz. These are configuration/readback evidence,
not an independently measured clock waveform.

## Producer integration

`include/ld2450_stream.h` and `src/stream.c` have no SDK or hardware dependencies.
All operations have one task owner; DMA/USB interrupt handlers must hand off
buffer ownership instead of calling these APIs concurrently.

1. Allocate the state and a caller-owned queue statically. Unit tests use an
   8 KiB queue; the target uses 48 KiB, pending USB capacity measurements.
   The x64 host state is 6,312 bytes, including 4,096 bytes of prediction
   history and a 2,093-byte message scratch buffer. Target ABI size and total
   application RAM/stack/heap must be measured separately. No complete raw
   frame is buffered by the producer and it performs no heap allocation.
2. Initialize with a 32-byte SHA-256 identifying the actual ordered radar
   configuration and acquisition settings. Define and retain that identity's
   input manifest in the acquisition adapter; test streams use an all-zero
   identity explicitly as synthetic data.
3. At an observed paired frame boundary call `ld_stream_begin` once, with an
   observed-frame counter (including skipped frames) and local microseconds.
   Select only when the previous output queue is empty; otherwise count an
   intentional whole-frame skip. Calling BEGIN while a frame is active rejects
   the old frame as incomplete. No inference of physical frame boundaries is
   implemented by this module.
4. Submit validated, assembled 2,056-byte DS RAW records. Each receiver must
   independently progress from chirp 0 through 63. Lanes may interleave in any
   order. The first chirp of each lane is raw, so each frame is independent.
   Startup records, missing chirps, identity/sequence errors or bad checksums
   reject the frame. Call `ld_stream_abort` on acquisition timeout, DMA overrun
   or updater entry, including when no further record arrives.
5. Pump a bounded byte budget between acquisition work. The transport callback
   must return promptly and **copy** accepted bytes before returning their
   count. Zero means temporary backpressure; a negative result means disconnect
   or transfer failure. An asynchronous DMA adapter needs its own owned buffer
   and must not retain a pointer into this queue after accepting bytes.

Messages enter the queue atomically. Every data insertion reserves 40 bytes for
ABORT, so overflow has an explicit terminal record even with a stalled host.
Previously queued bytes remain ordered and drain before another frame begins.
A transport error clears the queue, resets active state and counts loss; the
host discards any incomplete prefix and resynchronizes on a subsequent valid
BEGIN. It also invalidates unfinished frames at EOF/capture end.

Stats include completed encoding, rejected/skipped frames, invalid records,
overflows, transport errors, raw/compressed record counts and queue peak.
`frames_completed` counts complete frames **enqueued**, not host acknowledgments.
A disconnect before draining END also increments rejection. Only the host's
accepted complete-frame count establishes receipt; this protocol has no ACK or
retransmission. Counters/frame IDs/sequence/timestamps are uint32, wrapping
modulo 2^32. Timestamps are caller-provided observation times, not proven radar
sample timestamps, and are not compared as ordinary monotonic integers.

## Target integration and USB bench handoff

`stream_app.c` owns four 2,056-byte DMA slots per lane. SPI completion IRQs
rearm the next slot immediately; the main loop validates and encodes owned
records. `acquisition.c` pairs lane chirp-zero records within 5 ms and requires
ordered chirps 0..63 independently on both lanes. TIMER3 supplies microsecond
observation timestamps, wrapping as uint32; it is not a radar sampling clock.
A 200 ms missing-record timeout aborts an unfinished frame. A DMA ownership
overrun stops acquisition and powers down the radar until restart, avoiding
rearming in the middle of a physical record. Output backpressure instead
rejects/skips whole frames while continuing acquisition.

`usb_stream.c` uses the SDK EP0/device stack with project-owned CDC descriptors:
bulk IN/OUT endpoint 4, notification IN endpoint 2, 64-byte packets. The write
callback copies at most one packet into its own DMA buffer and returns zero
while busy; it does not call the vendor blocking `cdc_write_data`. Register
accessors still have bounded SDK polling loops whose loaded timing needs a
physical USB test. Reset, suspend, DTR loss and missing SOFs invalidate the
transport epoch. A new host receives a new independent frame after recovery.
The generated SDK configuration keeps USB buffers in ordinary BSS and leaves
EP0 available across suspend; the pinned SDK checkout is unchanged.

The laboratory descriptor currently inherits SDK VID/PID `4C4A:4155`, product
`LD2450 frame stream`, serial `LD2450-STREAM-01`. These are not an allocated
production identity. Windows enumeration and serial-driver binding are verified.

Startup keeps the three-second UART recovery window before USB/radar setup.
The running application's UART poll is bounded and retains split update
handshakes; a valid updater request first stops acquisition and USB. Module
UART remains PA1/PA0 at 256000 baud; PA9 diagnostics remain at 115200. Avoid
printing during acquisition: blocking startup prints previously filled the
DMA ring before the main loop could service it.

Sending ASCII `?` on the module UART snapshots DTR, configuration state, SOF age,
endpoint status and transfer counters, then **stops radar and USB** and prints
the report on PA9. It also reports clocks/registers and, if radar records were
encoded, bounded stopped-state CRC/encoder timing. Restart or use the UART updater to resume. This is a one-off diagnostic,
not a command for the native USB data port. The checked bench runner is
`firmware/tools/bench_stream.py`; it requires explicit ports and an image hash.

Measured static sizes: producer plus acquisition state 16,648 bytes, DMA
16,448 bytes, output queue 49,152 bytes. SDK heap counters reported 230,640
bytes, inconsistent with the physical internal-RAM budget; do not interpret
that figure as available physical RAM. Stack usage and allocator accounting
remain unqualified.

When native USB is connected, verify its COM port identity and run the capture
command below. Require accepted complete frames and preserved source hashes.
Then exercise reader stalls and reconnect, obtain the stopped PA9 report, and
compare acquisition errors, encoding time and queue peaks. If enumeration or
transport needs isolation, use the separately built `usb-bench` image first.

## Wire format v1

All envelope integers are little-endian; original radar bytes remain big-endian.
Each message is a 32-byte header, payload, then IEEE CRC-32 of the payload
(polynomial 0xEDB88320, initial/final xor 0xFFFFFFFF). Header CRC covers bytes
0..27. Header CRC and the 2,057-byte payload bound are checked before using
lengths. Maximum message size is 2,093 bytes. Empty payload CRC is zero.

| Offset | Bytes | Meaning |
| --- | --- | --- |
| 0 | 4 | ASCII `LDF1` |
| 4 | 1 | Protocol version 1 |
| 5 | 1 | Type: 1 BEGIN, 2 RECORD, 3 END, 4 ABORT |
| 6 | 1 | Codec: 1 for RECORD, 0 otherwise |
| 7 | 1 | Receiver 0/1; 255 for control messages |
| 8 | 2 | Payload length |
| 10 | 2 | Chirp 0..63; 65535 for control messages |
| 12 | 4 | Message sequence, consecutive within a frame |
| 16 | 4 | Observed radar frame ID |
| 20 | 4 | Local timestamp in microseconds |
| 24 | 4 | CRC-32 of reconstructed 2,056-byte record; zero for control |
| 28 | 4 | Header CRC-32 |

BEGIN has 52 payload bytes: configuration SHA-256 (32), cumulative skipped
frames (u32), rejected frames (u32), prior queue peak (u32), pairs=512 (u16),
chirps=64 (u16), receivers=2 (u8), codec version=1 (u8), reserved=0 (u16).
END has no payload and is valid only after all 128 records. ABORT has a u32
reason: 1 next boundary before completion, 2 invalid record, 3 queue overflow;
4 is the replay harness's incomplete-input reason; 5 is an acquisition gap,
timeout, stop or transport reset. Host rejection does not require parsing a reason.

RECORD payload starts with mode (u8), original header (4 bytes), original
trailer (4 bytes), then encoded I/Q. Mode 0 is 2,048 verbatim I/Q bytes.
Mode 1 subtracts the previous chirp from signed int16 samples independently
at each I/Q position. Encode d as z=2*d for d>=0, or -2*d-1 otherwise. For each
32-value block emit a one-byte bit width (0..17) then 32 z values MSB-first at
that width. Blocks are naturally byte aligned (4*width bytes). Width zero has
no value bytes. Use raw mode unless packed I/Q plus width bytes is strictly
smaller than 2,048 bytes. Never wrap residual arithmetic into int16. The host
rejects reconstructed samples outside int16 and validates original framing,
radar checksum and raw CRC before accepting a chirp.

## Host capture

Offline decoding needs only Python's standard library:

```powershell
python firmware/tools/frame_stream.py --input saved-stream.ldf --out output/decoded-new
```

Once the flashed streaming USB CDC firmware enumerates, the receiver
can read its explicit port (requires `pyserial`):

```powershell
python firmware/tools/frame_stream.py --port COMXX --seconds 30 --out output/usb-new
```

COMXX is a placeholder for that new CDC device, not the module's UART updater.
The existing capture image emits ASCII and cannot supply this protocol. The
CDC line-coding value is 115200; it is not a measured USB data-rate limit.
The tool sends no application commands. The serial library opens the port and
may assert control lines as part of CDC setup; hardware use requires a known
USB connection. Native USB capture is validated with the synthetic raw profile;
complete live-radar frame capture remains pending.

Each new output directory retains `stream.ldf`, its SHA-256 in `report.json`,
and separate accepted-frame directories with both original lane binaries,
hashes, configuration identity, per-chirp observation timestamps and device
counters. Incomplete/rejected data remains in the original stream. Existing
output directories are refused. A capture with no complete frame exits 1.

## Preserved baseline

Before source edits, 148 source/build/evidence files were archived locally in
`firmware/build/baseline-before-stream-20261006/baseline.zip`, with per-file
hashes in `manifest.json`. Archive SHA-256:
`c6877225654e608a018543b15066b098796cce3d20cf3859ec58a8680bafc411`.
The preserved `spi-capture16/update-two-wire.ufw` matches the prior reference:
`16381b9302ccceaa48af63f7459c293fccbeb042064be85432480fbb575f6fb5`.
This archive is in ignored build storage, not a committed release or a claim
that the entire working tree is clean. Existing uncommitted work was retained.
