#ifndef LD2450_STREAM_APP_H
#define LD2450_STREAM_APP_H
#include <stddef.h>
#include <stdint.h>
int ld2450_stream_app_init(void);
int ld2450_stream_app_arm(void);
void ld2450_stream_app_poll(void);
void ld2450_stream_app_stop(void);
void ld2450_stream_app_report(void); /* Explicit '?' UART command stops acquisition. */
uint32_t ld2450_stream_clock_us(void);
int ld2450_usb_init(void);
void ld2450_usb_stop(void);
int ld2450_usb_ready(void);
int ld2450_usb_write(void *, const uint8_t *, size_t);
void ld2450_usb_flush(void);
uint32_t ld2450_usb_epoch(void);
void ld2450_usb_bus_suspend(void);
struct ld2450_usb_diagnostics {
    uint32_t initialized, dtr, device_state, epoch, sof, sof_age_ms, txcsr;
    uint32_t resets, suspends, control_requests, control_value;
    uint32_t ready_polls, writes, busy, bytes;
};
void ld2450_usb_snapshot(struct ld2450_usb_diagnostics *);
#endif
