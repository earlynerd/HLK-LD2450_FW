#include "ld2450_stream.h"
#include "radar_wire.h"
#include <string.h>

#define ABORT_RESERVE 40u
#ifdef LD2450_USB_STREAM
/* SDK startup copies these sections into internal RAM. Keep the CRC lookup
 * and tight dependent-load loop off the mapped-flash path. */
#define CRC_CODE __attribute__((section(".volatile_ram_code"),noinline))
#define CRC_TABLE __attribute__((section(".data")))
#else
#define CRC_CODE
#define CRC_TABLE
#endif
static void le16(uint8_t *p, uint16_t v) { p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static void le32(uint8_t *p, uint32_t v) { le16(p,(uint16_t)v); le16(p+2,(uint16_t)(v>>16)); }
static int32_t signed_be16(const uint8_t *p)
{
    uint32_t v=((uint32_t)p[0]<<8)|p[1];
    return (int32_t)(v^0x8000u)-32768;
}
CRC_CODE uint32_t ld_stream_crc32(const uint8_t *data, size_t size)
{
    /* Reflected IEEE CRC-32, one byte per lookup. The bit-at-a-time version
     * exceeded the target's DMA service budget when a frame began. */
    static const uint32_t table[256] CRC_TABLE={
    0x00000000u,0x77073096u,0xee0e612cu,0x990951bau,0x076dc419u,0x706af48fu,0xe963a535u,0x9e6495a3u,
    0x0edb8832u,0x79dcb8a4u,0xe0d5e91eu,0x97d2d988u,0x09b64c2bu,0x7eb17cbdu,0xe7b82d07u,0x90bf1d91u,
    0x1db71064u,0x6ab020f2u,0xf3b97148u,0x84be41deu,0x1adad47du,0x6ddde4ebu,0xf4d4b551u,0x83d385c7u,
    0x136c9856u,0x646ba8c0u,0xfd62f97au,0x8a65c9ecu,0x14015c4fu,0x63066cd9u,0xfa0f3d63u,0x8d080df5u,
    0x3b6e20c8u,0x4c69105eu,0xd56041e4u,0xa2677172u,0x3c03e4d1u,0x4b04d447u,0xd20d85fdu,0xa50ab56bu,
    0x35b5a8fau,0x42b2986cu,0xdbbbc9d6u,0xacbcf940u,0x32d86ce3u,0x45df5c75u,0xdcd60dcfu,0xabd13d59u,
    0x26d930acu,0x51de003au,0xc8d75180u,0xbfd06116u,0x21b4f4b5u,0x56b3c423u,0xcfba9599u,0xb8bda50fu,
    0x2802b89eu,0x5f058808u,0xc60cd9b2u,0xb10be924u,0x2f6f7c87u,0x58684c11u,0xc1611dabu,0xb6662d3du,
    0x76dc4190u,0x01db7106u,0x98d220bcu,0xefd5102au,0x71b18589u,0x06b6b51fu,0x9fbfe4a5u,0xe8b8d433u,
    0x7807c9a2u,0x0f00f934u,0x9609a88eu,0xe10e9818u,0x7f6a0dbbu,0x086d3d2du,0x91646c97u,0xe6635c01u,
    0x6b6b51f4u,0x1c6c6162u,0x856530d8u,0xf262004eu,0x6c0695edu,0x1b01a57bu,0x8208f4c1u,0xf50fc457u,
    0x65b0d9c6u,0x12b7e950u,0x8bbeb8eau,0xfcb9887cu,0x62dd1ddfu,0x15da2d49u,0x8cd37cf3u,0xfbd44c65u,
    0x4db26158u,0x3ab551ceu,0xa3bc0074u,0xd4bb30e2u,0x4adfa541u,0x3dd895d7u,0xa4d1c46du,0xd3d6f4fbu,
    0x4369e96au,0x346ed9fcu,0xad678846u,0xda60b8d0u,0x44042d73u,0x33031de5u,0xaa0a4c5fu,0xdd0d7cc9u,
    0x5005713cu,0x270241aau,0xbe0b1010u,0xc90c2086u,0x5768b525u,0x206f85b3u,0xb966d409u,0xce61e49fu,
    0x5edef90eu,0x29d9c998u,0xb0d09822u,0xc7d7a8b4u,0x59b33d17u,0x2eb40d81u,0xb7bd5c3bu,0xc0ba6cadu,
    0xedb88320u,0x9abfb3b6u,0x03b6e20cu,0x74b1d29au,0xead54739u,0x9dd277afu,0x04db2615u,0x73dc1683u,
    0xe3630b12u,0x94643b84u,0x0d6d6a3eu,0x7a6a5aa8u,0xe40ecf0bu,0x9309ff9du,0x0a00ae27u,0x7d079eb1u,
    0xf00f9344u,0x8708a3d2u,0x1e01f268u,0x6906c2feu,0xf762575du,0x806567cbu,0x196c3671u,0x6e6b06e7u,
    0xfed41b76u,0x89d32be0u,0x10da7a5au,0x67dd4accu,0xf9b9df6fu,0x8ebeeff9u,0x17b7be43u,0x60b08ed5u,
    0xd6d6a3e8u,0xa1d1937eu,0x38d8c2c4u,0x4fdff252u,0xd1bb67f1u,0xa6bc5767u,0x3fb506ddu,0x48b2364bu,
    0xd80d2bdau,0xaf0a1b4cu,0x36034af6u,0x41047a60u,0xdf60efc3u,0xa867df55u,0x316e8eefu,0x4669be79u,
    0xcb61b38cu,0xbc66831au,0x256fd2a0u,0x5268e236u,0xcc0c7795u,0xbb0b4703u,0x220216b9u,0x5505262fu,
    0xc5ba3bbeu,0xb2bd0b28u,0x2bb45a92u,0x5cb36a04u,0xc2d7ffa7u,0xb5d0cf31u,0x2cd99e8bu,0x5bdeae1du,
    0x9b64c2b0u,0xec63f226u,0x756aa39cu,0x026d930au,0x9c0906a9u,0xeb0e363fu,0x72076785u,0x05005713u,
    0x95bf4a82u,0xe2b87a14u,0x7bb12baeu,0x0cb61b38u,0x92d28e9bu,0xe5d5be0du,0x7cdcefb7u,0x0bdbdf21u,
    0x86d3d2d4u,0xf1d4e242u,0x68ddb3f8u,0x1fda836eu,0x81be16cdu,0xf6b9265bu,0x6fb077e1u,0x18b74777u,
    0x88085ae6u,0xff0f6a70u,0x66063bcau,0x11010b5cu,0x8f659effu,0xf862ae69u,0x616bffd3u,0x166ccf45u,
    0xa00ae278u,0xd70dd2eeu,0x4e048354u,0x3903b3c2u,0xa7672661u,0xd06016f7u,0x4969474du,0x3e6e77dbu,
    0xaed16a4au,0xd9d65adcu,0x40df0b66u,0x37d83bf0u,0xa9bcae53u,0xdebb9ec5u,0x47b2cf7fu,0x30b5ffe9u,
    0xbdbdf21cu,0xcabac28au,0x53b39330u,0x24b4a3a6u,0xbad03605u,0xcdd70693u,0x54de5729u,0x23d967bfu,
    0xb3667a2eu,0xc4614ab8u,0x5d681b02u,0x2a6f2b94u,0xb40bbe37u,0xc30c8ea1u,0x5a05df1bu,0x2d02ef8du,
    };
    uint32_t crc=0xffffffffu;
    size_t n;
    for (n=0;n<size;++n) crc=(crc>>8)^table[(crc^data[n])&255u];
    return crc^0xffffffffu;
}
static uint32_t residual(const uint8_t *a, const uint8_t *b)
{
    int32_t d=signed_be16(a)-signed_be16(b);
    return d<0 ? (uint32_t)(-2*d-1) : (uint32_t)(2*d);
}
size_t ld_stream_encode(const uint8_t *r, const uint8_t *prev, uint8_t *out, size_t cap)
{
    size_t block, j, pos=9;
    unsigned width;
    uint32_t values[32];
    if (!r || !out || cap<LD_STREAM_PAYLOAD_MAX) return 0;
#ifdef LD2450_STREAM_RAW_ONLY
    prev=NULL; /* Explicit USB-only diagnostic; wire raw mode is unchanged. */
#endif
    memcpy(out+1,r,4); memcpy(out+5,r+2052,4);
    if (!prev) goto raw;
    out[0]=1;
    for (block=0;block<32;++block) {
        uint32_t bits=0,maximum=0;
        unsigned pending=0;
        /* Cache one block's residuals instead of reading and decoding the
         * big-endian input a second time during packing. */
        for(j=0;j<32;++j) {
            size_t at=2*(block*32+j);
            uint32_t z=residual(r+4+at,prev+at);
            values[j]=z;if(z>maximum) maximum=z;
        }
        width=0;while(maximum) {++width;maximum>>=1;}
        /* Stop before exceeding scratch capacity; raw wins ties too. */
        if(pos+1+4*width>=2057) goto raw;
        out[pos++]=(uint8_t)width;
        if(!width) continue;
        for (j=0;j<32;++j) {
            uint32_t z=values[j];
            /* At most seven pending bits plus a 17-bit residual: all shifts
             * fit uint32. Each 32-value block ends on a byte boundary. */
            bits=(bits<<width)|z;pending+=width;
            while(pending>=8) {
                pending-=8;out[pos++]=(uint8_t)(bits>>pending);
            }
        }
    }
    return pos;
raw:
    out[0]=0;memcpy(out+9,r+4,2048);return 2057;
}
static void enqueue(struct ld_stream *s, const uint8_t *p, size_t size)
{
    size_t tail=(s->head+s->used)%s->capacity;
    size_t first=s->capacity-tail;
    if (first>size) first=size;
    memcpy(s->queue+tail,p,first); memcpy(s->queue,p+first,size-first);
    s->used+=size;
    if (s->used>s->stats.queue_peak) s->stats.queue_peak=(uint32_t)s->used;
}
/* Payload already in scratch+32; every message is enqueued atomically. */
static void message(struct ld_stream *s, uint8_t type, uint8_t lane,
                    uint16_t chirp, uint32_t time, size_t payload, uint32_t raw_crc)
{
    uint8_t *p=s->scratch;
    memcpy(p,"LDF1",4); p[4]=1; p[5]=type; p[6]=(uint8_t)(type==2); p[7]=lane;
    le16(p+8,(uint16_t)payload); le16(p+10,chirp);
    le32(p+12,s->sequence++); le32(p+16,s->frame); le32(p+20,time);
    le32(p+24,raw_crc); le32(p+28,ld_stream_crc32(p,28));
    le32(p+32+payload,ld_stream_crc32(p+32,payload));
    enqueue(s,p,36+payload);
}
int ld_stream_init(struct ld_stream *s, uint8_t *queue, size_t capacity, const uint8_t *config)
{
    if (!s || !queue || !config || capacity<LD_STREAM_MESSAGE_MAX+ABORT_RESERVE ||
        capacity>65535u) return -1;
    memset(s,0,sizeof(*s)); s->queue=queue; s->capacity=capacity;
    memcpy(s->config_sha256,config,32); return 0;
}
void ld_stream_abort(struct ld_stream *s, uint32_t reason, uint32_t time)
{
    if (!s || !s->active) return;
    s->active=0; ++s->stats.frames_rejected;
    le32(s->scratch+32,reason);
    message(s,4,255,65535,time,4,0); /* Reserved even at maximum backlog. */
}
int ld_stream_begin(struct ld_stream *s, uint32_t frame, uint32_t time)
{
    uint8_t *p;
    if (!s || !s->queue) return -1;
    if (s->active) ld_stream_abort(s,1,time); /* Missing prior frame tail. */
    if (s->used) { ++s->stats.frames_skipped; return 0; }
    s->frame=frame; s->active=1; s->next_chirp[0]=s->next_chirp[1]=0;
    p=s->scratch+32; memcpy(p,s->config_sha256,32);
    le32(p+32,s->stats.frames_skipped); le32(p+36,s->stats.frames_rejected);
    le32(p+40,s->stats.queue_peak); le16(p+44,512); le16(p+46,64);
    p[48]=2; p[49]=1; le16(p+50,0);
    message(s,1,255,65535,time,52,0); return 1;
}
int ld_stream_record(struct ld_stream *s, const uint8_t *r, size_t size, uint32_t time)
{
    struct radar_record decoded;
    size_t encoded;
    uint8_t lane;
    if (!s || !s->active) return 0;
    if (size!=2056 || radar_record_decode(r,size,&decoded)!=RADAR_RECORD_VALID ||
        decoded.declared_pairs!=512 || decoded.chirp>=64 ||
        decoded.chirp!=s->next_chirp[decoded.rx_index]) {
        ++s->stats.invalid_records; ld_stream_abort(s,2,time); return -1;
    }
    lane=decoded.rx_index;
    encoded=ld_stream_encode(r,s->next_chirp[lane] ? s->previous[lane] : NULL,
                            s->scratch+32,LD_STREAM_PAYLOAD_MAX);
    if (encoded+36+ABORT_RESERVE>s->capacity-s->used) {
        ++s->stats.queue_overflows; ld_stream_abort(s,3,time); return -1;
    }
    if (s->scratch[32]) ++s->stats.compressed_records; else ++s->stats.raw_records;
    message(s,2,lane,decoded.chirp,time,encoded,ld_stream_crc32(r,size));
    memcpy(s->previous[lane],r+4,2048); ++s->next_chirp[lane];
    if (s->next_chirp[0]==64 && s->next_chirp[1]==64) {
        message(s,3,255,65535,time,0,0);
        s->active=0; s->pending_complete=1; ++s->stats.frames_completed;
    }
    return 1;
}
int ld_stream_pump(struct ld_stream *s, ld_stream_write_fn write, void *context, size_t budget)
{
    size_t count; int accepted;
    if (!s || !write || !s->queue) return -1;
    if (!s->used || !budget) return 0;
    count=s->capacity-s->head;
    if (count>s->used) count=s->used;
    if (count>budget) count=budget;
    accepted=write(context,s->queue+s->head,count);
    if (accepted<0 || (size_t)accepted>count) {
        ++s->stats.transport_errors;
        if (s->active || s->pending_complete) ++s->stats.frames_rejected;
        s->active=0; s->pending_complete=0; s->head=0; s->used=0;
        /* Bytes already delivered may be a prefix: host resyncs on valid BEGIN. */
        return -1;
    }
    s->head=(s->head+(size_t)accepted)%s->capacity; s->used-=(size_t)accepted;
    if (!s->used) s->pending_complete=0;
    return accepted;
}
