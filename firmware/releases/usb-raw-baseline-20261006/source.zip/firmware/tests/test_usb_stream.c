#include <stdio.h>
#include "../target/br23/image/usb_stream.c"
int main(void) {
    u8 descriptor[128],data[100];u32 itf=0,n,pos;
    struct usb_ctrlrequest r={0x21,0x22,1,0,0};
    struct ld2450_usb_diagnostics diag;
    assert(ld2450_usb_init()==0);reset(&device,0);device.bDeviceStates=USB_CONFIGURED;
    n=cdc_desc_config(0,descriptor,&itf);assert(itf==2);
    for(pos=0;pos<n;pos+=descriptor[pos]) {
        assert(descriptor[pos]>=4 && pos+descriptor[pos]<=n);
        if(descriptor[pos+1]==5) assert((descriptor[pos+2]&15)<5);
    }
    assert(!ld2450_usb_ready());setup(&device,&r);assert(ld2450_usb_ready());
    memset(data,0xa5,sizeof(data));
    assert(ld2450_usb_write(NULL,data,100)==64 && txcount==64 && submits==1);
    memset(data,0x5a,sizeof(data));assert(dma_in[0]==0xa5); /* Owned copy. */
    assert(ld2450_usb_write(NULL,data,10)==0 && submits==1);
    ld2450_usb_snapshot(&diag);
    assert(diag.dtr==1 && diag.resets==1 && diag.suspends==0 && diag.control_requests==1);
    assert(diag.writes==1 && diag.bytes==64 && diag.busy==1 && diag.ready_polls==1);
    txcsr=0;ld2450_usb_flush();assert(txcount==0 && submits==2);
    txcsr=0;assert(ld2450_usb_write(NULL,data,7)==7);
    txcsr=0;ld2450_usb_flush();assert(submits==3); /* No unnecessary ZLP. */
    r.wValue=0;setup(&device,&r);assert(!ld2450_usb_ready() && ld2450_usb_write(NULL,data,1)==0);
    r.wValue=1;setup(&device,&r);now=101;assert(!ld2450_usb_ready());
    ++sof;assert(ld2450_usb_ready());
    ld2450_usb_bus_suspend();assert(!ld2450_usb_ready());
    r.bRequest=0x20;r.wLength=65;r.wValue=0;setup(&device,&r);assert(setup_phase==USB_EP0_SET_STALL);
    assert(coding_rx(&device,&r)==USB_EP0_SET_STALL && ep_reads==0);
    r.wLength=7;assert(coding_rx(&device,&r)==0 && ep_reads==1);
    assert(!locked);ld2450_usb_stop();assert(!ld2450_usb_ready());
    puts("CDC descriptors, owned TX, stalls, DTR, reset, SOF timeout and setup bounds passed");return 0;
}
