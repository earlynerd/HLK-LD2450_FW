# Live radar viewer

A local browser workspace for the custom firmware's validated LDF1 feed. It
shows both receivers' I/Q waveforms and spectra, spectral history, an exploratory
within-frame Doppler map, and transport/processing health. It does not require a
firmware change or a web service. Dependencies are NumPy and pyserial; the UI
uses browser Canvas with no package build or external assets.

## Start

From the repository root on this computer:

```powershell
.\tools\start_radar_viewer.ps1
```

The launcher reuses an existing viewer, or starts one hidden and opens
http://127.0.0.1:8765. Its logs and PID are in `output/live_radar/`. Closing the
browser does not stop acquisition: use **Disconnect** to release the USB port.
For a foreground server with Ctrl+C shutdown:

```powershell
C:\ProgramData\miniconda3\python.exe tools/live_radar.py --connect
```

On another Python environment, install `tools/radar_viewer/requirements.txt`.
For offline use, omit `--connect` and choose a recording in the UI, or use:

```powershell
python tools/live_radar.py --replay output/stream_bench/usb_budget_guard_capture/stream.ldf
```

Only one process can own native USB COM30. The viewer discovers the matching
VID/PID/serial identity (`4c4a:4155`, `LD2450-STREAM-01`) and asserts DTR. It never
opens debug/updater UART ports, sends radar commands, or flashes firmware.
An unplug or serial error stops the source and surfaces the error. Reconnect
explicitly once the device is available. The server binds only to loopback;
mutating requests also require a per-process token and a matching browser origin.

## Explore

- **Complex waveform:** choose a chirp or the mean of all captured chirps. The
  slider and mean adapt to the declared 16- or 64-chirp export. Both I and Q
  from both receivers are shown. DC removal follows the frame's processing
  setting; background subtraction does not alter this source-data plot.
- **Frame spectrum:** 512-point complex FFT, normalized by the window sum, RMS
  spectral amplitude across chirps, in dB relative to one exported sample count.
  Hann/rectangular and per-chirp complex DC removal are selectable.
- **Spectrum history:** the last 160 spectra displayed in this browser. Newest
  at the bottom. Rows are displayed frames, not a uniform time axis: firmware
  intentionally skips export frames, and browser refresh can skip views too.
- **Doppler:** 16- or 64-chirp Hann FFT across fast-time bins -64 through +64. Optional
  static removal subtracts the within-frame mean complex spectrum before the
  slow-time FFT. Frequency uses the median reported chirp interval (typically
  1200 us: about 52.1 Hz/bin for 16 chirps, or 13.0 Hz/bin for 64).
  Timing outliers are reported, not silently repaired.
- **Background:** capture the mean complex waveform of the latest acquired
  frame for each receiver, then subtract it before spectrum/Doppler processing.
  Source changes, configuration changes and replay loops clear the reference.
  The capture is session-local. It is not saved as a calibration.
- **Freeze display:** continues reading, decoding and optional recording while
  holding the displayed frame. Chirp/receiver/heatmap controls still work.
  Resume starts a fresh history. Processing changes apply to newly processed
  frames, not the frozen view. **Save latest acquired frame** and **Capture
  background** always act on the current acquisition, even when display is frozen.
- **Raw recording:** retains original wire bytes plus a SHA-256 manifest in a
  new `output/live_radar/*-capture-*` folder. Stops at 1 GiB or disconnect. Starts
  and ends can be mid-frame; replay resynchronizes and only publishes complete
  frames. Refresh the recording list after creating captures in another client.
- **Save latest acquired frame:** exports two exact validated lane binaries and
  their hash manifest, source and processing settings, to a new snapshot folder.
  It does not modify the frame in memory. The raw data is retained unchanged.

Recordings loop at approximately their original timestamp spacing, with very
long gaps capped at two seconds. Known capture directories are listed; an
arbitrary file can be supplied on the trusted command line with `--replay`.
Older diagnostic captures named `raw` may contain synthetic benchmark data;
their configuration identities and source names remain visible.

## Interpretation limits

FFT bin is not distance. Full-record FFTs may combine multiple ramp segments;
sample rate, chirp slope and sample-to-ramp alignment still need calibration.
The Doppler map is exploratory, not a calibrated range/velocity map. Neither
receiver phase nor an amplitude peak is reported as bearing or an identified
target. The spectra are not dBm measurements.

Within-frame variation is RMS residual after subtracting the frame's mean
DC-centered waveform, divided by the DC-centered RMS amplitude. It includes
noise, drift and motion; it is not target SNR. ADC saturation cannot be ruled
out just because the exported int16 samples do not reach the numerical rails.

Health counters distinguish host parser/protocol failures, rejected complete
frame candidates, firmware skips/rejections (cumulative since boot), and dropped
display-processing work. **Rejected exports** includes deliberate firmware
ABORT messages; **Buffer-full aborts** (reason 3) and **CPU-guard aborts** (reason
6) identify their causes. **Invalid / incomplete** excludes explicit ABORTs.
Device totals update from validated BEGIN messages even when candidates abort;
wire throughput remains visible when there are no completed frames. The badge
shows **EXPORT LIMITED** when recent firmware aborts prevent fresh frames.
Parser counters include initial resynchronization:
the previously observed 64-byte USB prefix on reconnect can increment them
without invalidating a subsequently accepted frame. Export skips are expected.
Timing outliers count intervals more than 10% from the frame median, separately
for both lanes; these are timestamp observations, not proven physical jitter.
During looping replay, parser/protocol/rejected-candidate counters describe the
current pass; byte/frame totals span all passes. Connecting a source resets the
host counters.

The 2026-10-06 motion demonstration confirmed a firmware export limitation:
305 completed frames, 71 CPU-guard aborts, 53 output-buffer aborts, and one
additional resynchronization rejection in the recorded interval. Clear reason
counters diagnose this; they do not resolve the firmware's motion-dependent
compression/queue/CPU limits of that 64-chirp image. Evidence is in
`output/live_radar/20261006-173642-capture-3fc19b/analysis.json`.

The subsequent raw 16-chirp firmware exports chirps 0-15 from both receivers,
with all 512 complex samples per chirp. Its complete 67,100-byte wire export fits
the existing producer queue without compression or concurrent USB draining.
The radar still produces 64 physical chirps; exports deliberately cover only the
first 16, and whole physical frames can be skipped while USB output drains.
See `firmware/docs/FRAME_STREAM.md` for the installed image and bench evidence.

## Extend processing

The integrity boundary is the existing `firmware/tools/frame_stream.py` decoder.
Only its complete, checksum/CRC-validated, paired 16- or 64-chirp export is published.
The viewer neither weakens checks nor introduces another wire decoder.

`tools/radar_viewer/server.py` separates USB reading, frame decoding, and DSP:

1. USB reader feeds a bounded 4 MiB byte queue; recording keeps the original
   bytes. Overflow stops with a visible error instead of dropping hidden bytes.
2. Decoder produces verified frames. The one-frame processing queue replaces an
   older pending display frame if necessary; the drop is counted independently
   of device export loss. Recording remains independent of display work.
3. `processing.Pipeline` unpacks `(receiver, chirp, sample, I/Q)` and constructs
   `FrameContext`. Its named `stages` mapping publishes JSON-compatible products.
   Stage exceptions appear as named errors; other stages can still render.
4. The browser polls the latest result. Slow/frozen/closed browsers never block
   acquisition. It retains only one frame plus 160 displayed spectra. Settings
   and configuration generations prevent combining different processing modes
   in the same waterfall history.

To add a range estimator, phase/coherence stage, motion detector or angle solver:
implement a function taking `FrameContext`, add it to `Pipeline.stages`, and add
a corresponding plot in `web/app.js` / `web/index.html`. Retain units and
calibration identity with each new product. Use `ctx.raw` for unchanged complex
samples, `ctx.signal` for optional DC/background removal, or `ctx.spectra` for
the normalized fast-time FFT. Stage execution must stay bounded; heavy work can
drop display frames but must not alter the acquisition integrity contract.

Tests from the repository root:

```powershell
python -m unittest discover -s tools -p test_viewer.py -v
```

Tests cover complex FFT sign/amplitude, Doppler frequency, timestamp rollover,
background/config changes, static rejection, stage-failure isolation, endian
roundtrip, corruption recovery, bounded display backlog, port identity,
recording hashes, replay/snapshot lifecycle, and local HTTP control protection.
