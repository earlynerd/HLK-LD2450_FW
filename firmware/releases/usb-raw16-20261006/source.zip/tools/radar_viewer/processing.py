"""Processing stages operate on complete frames; axes stay uncalibrated.

Add a stage to Pipeline.stages to publish another named product. Each stage
receives a FrameContext and returns JSON-compatible data. Acquisition and the
LDF1 integrity boundary do not need to change when adding a stage.
"""
from dataclasses import dataclass
import base64
import time

import numpy as np


DEFAULT_SETTINGS = {"remove_dc": True, "window": "hann", "remove_static": True}


def validate_settings(values):
    if set(values) != set(DEFAULT_SETTINGS):
        raise ValueError("Settings must contain remove_dc, window and remove_static")
    if type(values["remove_dc"]) is not bool or type(values["remove_static"]) is not bool:
        raise ValueError("DC and static removal must be booleans")
    if values["window"] not in ("hann", "rectangular"):
        raise ValueError("Unknown window")
    return dict(values)


def unpack_iq(frame):
    chirps = frame.get('chirps', 64)
    if chirps not in (16, 64) or any(len(lane) != chirps * 2056 for lane in frame['lanes']):
        raise ValueError('Invalid complete export window')
    return np.stack([
        np.frombuffer(lane, dtype=">i2").reshape(chirps, 1028)[:, 2:-2].reshape(chirps, 512, 2)
        for lane in frame["lanes"]
    ]).astype("<i2")


def db(value):
    return np.round(20 * np.log10(np.maximum(value, 1e-6)), 2).tolist()


@dataclass
class FrameContext:
    frame: dict
    iq: np.ndarray
    raw: np.ndarray
    signal: np.ndarray
    spectra: np.ndarray
    settings: dict
    chirp_interval_s: float


def signal_quality(ctx):
    centered = ctx.raw - ctx.raw.mean(axis=-1, keepdims=True)
    residual = centered - centered.mean(axis=1, keepdims=True)
    rms = np.sqrt(np.mean(abs(centered) ** 2, axis=(1, 2)))
    residual_rms = np.sqrt(np.mean(abs(residual) ** 2, axis=(1, 2)))
    intervals = (np.diff(np.asarray(ctx.frame["timestamps_us"], dtype=np.int64), axis=1)
                 & 0xffffffff)
    median = float(np.median(intervals))
    return {
        "ac_rms": np.round(rms, 2).tolist(),
        "residual_rms": np.round(residual_rms, 2).tolist(),
        "residual_percent": np.round(100 * residual_rms / np.maximum(rms, 1e-9), 2).tolist(),
        "rail_samples": int(np.count_nonzero((ctx.iq == -32768) | (ctx.iq == 32767))),
        "chirp_interval_us": median,
        "timing_outliers": int(np.count_nonzero(abs(intervals - median) > median * .1)),
    }


def spectrum(ctx):
    return {"db": db(np.sqrt(np.mean(abs(ctx.spectra) ** 2, axis=1))),
            "bins": [-256, 255], "unit": "dB re 1 exported count"}


def doppler(ctx):
    # Full-record fast-time FFT is exploratory until ramp alignment is known.
    values = ctx.spectra[:, :, 192:321]  # Signed fast-time bins -64 through +64.
    if ctx.settings["remove_static"]:
        values = values - values.mean(axis=1, keepdims=True)
    chirps = ctx.iq.shape[1]
    window = np.hanning(chirps)
    transformed = np.fft.fftshift(np.fft.fft(values * window[None, :, None], axis=1), axes=1)
    transformed /= window.sum()
    freq = np.fft.fftshift(np.fft.fftfreq(chirps, ctx.chirp_interval_s))
    return {"db": db(abs(transformed)), "fast_bins": [-64, 64],
            "hz": np.round(freq, 3).tolist(), "unit": "dB re 1 exported count"}


class Pipeline:
    def __init__(self):
        self.stages = {"quality": signal_quality, "spectrum": spectrum, "doppler": doppler}
        self.reference = None
        self.reference_config = None
        self.reference_frame = None

    def set_reference(self, frame):
        iq = unpack_iq(frame)
        self.reference = (iq[..., 0] + 1j * iq[..., 1]).mean(axis=1, keepdims=True)
        self.reference_config = frame["config_sha256"]
        self.reference_frame = frame["frame_id"]

    def clear_reference(self):
        self.reference = self.reference_config = self.reference_frame = None

    def process(self, frame, settings):
        started = time.perf_counter()
        settings = validate_settings(settings)
        iq = unpack_iq(frame)
        raw = iq[..., 0].astype(np.float32) + 1j * iq[..., 1].astype(np.float32)
        if self.reference_config != frame["config_sha256"]:
            self.clear_reference()
        signal = raw.copy()
        if self.reference is not None:
            signal -= self.reference
        if settings["remove_dc"]:
            signal -= signal.mean(axis=-1, keepdims=True)
        window = np.hanning(512) if settings["window"] == "hann" else np.ones(512)
        spectra = np.fft.fftshift(np.fft.fft(signal * window, axis=-1), axes=-1) / window.sum()
        intervals = np.diff(np.asarray(frame["timestamps_us"], dtype=np.int64), axis=1) & 0xffffffff
        interval_s = float(np.median(intervals)) / 1e6
        if not 0 < interval_s < 1:
            raise ValueError("Invalid chirp interval; cannot form a Doppler frequency axis")
        ctx = FrameContext(frame, iq, raw, signal, spectra, settings, interval_s)
        products, errors = {}, {}
        for name, stage in self.stages.items():
            try:
                products[name] = stage(ctx)
            except Exception as exc:
                errors[name] = str(exc)
        return {
            "frame_id": frame["frame_id"], "config_sha256": frame["config_sha256"],
            "started_us": frame["started_us"], "settings": settings,
            "reference_frame": self.reference_frame,
            "chirps": int(iq.shape[1]), "iq_shape": list(iq.shape), "iq_dtype": "int16-le",
            "iq_base64": base64.b64encode(iq.tobytes()).decode("ascii"),
            "products": products, "stage_errors": errors,
            "processing_ms": round((time.perf_counter() - started) * 1000, 2),
        }
