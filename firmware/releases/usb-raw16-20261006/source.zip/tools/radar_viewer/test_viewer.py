"""Signal invariants and the viewer's validated-frame / local-control boundary."""
import base64
import hashlib
import http.client
import json
from pathlib import Path
import queue
import struct
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import numpy as np

from .processing import Pipeline, DEFAULT_SETTINGS, unpack_iq
from . import server
from frame_stream import HEADER, crc, Parser, Frames, Message


def fixture(fast_bin=12, slow_bin=5, frame_id=7, config="ab" * 32, chirps=64):
    n = np.arange(512)[None, :]
    c = np.arange(chirps)[:, None]
    z = 1000 * np.exp(2j * np.pi * (n * fast_bin / 512 + c * slow_bin / chirps)) + (3000 - 1500j)
    lane_bytes = []
    for lane in range(2):
        records = []
        for chirp in range(chirps):
            iq = np.stack((z[chirp].real, z[chirp].imag), axis=-1).round().astype(">i2").tobytes()
            records.append(struct.pack(">I", 0xaa200201 | lane << 22 | chirp << 11) + iq +
                           struct.pack(">HH", sum(struct.unpack(">1024H", iq)) & 65535,
                                       lane << 14 | 0x2000 | (chirp & 15) << 8 | 0x55))
        lane_bytes.append(b"".join(records))
    stamps = [(0xffffff00 + 1200 * i) & 0xffffffff for i in range(chirps)]
    return dict(chirps=chirps, frame_id=frame_id, config_sha256=config, started_us=stamps[0],
                ended_us=stamps[-1], device_skipped=2, device_rejected=0,
                device_queue_peak=100, lanes=lane_bytes, timestamps_us=[stamps, stamps])


def wire(frame):
    sequence = 0
    def packet(kind, payload, lane=255, chirp=65535, raw_crc=0):
        nonlocal sequence
        head = HEADER.pack(b"LDF1", 1, kind, int(kind == 2), lane, len(payload), chirp,
                           sequence, frame["frame_id"], frame["started_us"] if chirp == 65535 else frame["timestamps_us"][lane][chirp], raw_crc, 0)
        sequence += 1
        return head[:28] + struct.pack("<I", crc(head[:28])) + payload + struct.pack("<I", crc(payload))
    output = packet(1, bytes.fromhex(frame["config_sha256"]) + struct.pack("<IIIHHBBH", 2, 0, 100, 512, frame["chirps"], 2, 1, 0))
    for chirp in range(frame["chirps"]):
        for lane in range(2):
            record = frame["lanes"][lane][chirp * 2056:(chirp + 1) * 2056]
            output += packet(2, b"\0" + record[:4] + record[-4:] + record[4:-4], lane, chirp, crc(record))
    return output + packet(3, b"")


class ProcessingTests(unittest.TestCase):
    def test_raw16_decode_and_doppler_scale(self):
        frame = fixture(chirps=16, slow_bin=2)
        parser, frames = Parser(), Frames()
        accepted = None
        for message in parser.feed(wire(frame)):
            result = frames.accept(message)
            if result: accepted = result
        self.assertIsNotNone(accepted)
        self.assertEqual(accepted["chirps"],16)
        result = Pipeline().process(accepted,DEFAULT_SETTINGS)
        self.assertEqual(result["iq_shape"],[2,16,512,2])
        self.assertEqual(len(base64.b64decode(result["iq_base64"])),65536)
        doppler = result["products"]["doppler"]
        row, col = np.unravel_index(np.argmax(doppler["db"][0]),(16,129))
        self.assertEqual((row-8,col-64),(2,12))
        self.assertAlmostEqual(doppler["hz"][row],2/(16*.0012),places=3)

    def test_complex_fft_sign_amplitude_and_doppler_frequency(self):
        result = Pipeline().process(fixture(), DEFAULT_SETTINGS)
        spectrum = np.asarray(result["products"]["spectrum"]["db"])
        self.assertEqual(int(np.argmax(spectrum[0])) - 256, 12)
        self.assertAlmostEqual(spectrum[0, 268], 60, delta=.03)
        doppler = result["products"]["doppler"]
        row, col = np.unravel_index(np.argmax(doppler["db"][0]), (64, 129))
        self.assertEqual((row - 32, col - 64), (5, 12))
        self.assertAlmostEqual(doppler["hz"][row], 5 / (64 * .0012), places=3)
        self.assertEqual(result["products"]["quality"]["timing_outliers"], 0)  # Includes uint32 rollover.

    def test_wire_iq_endianness_roundtrip(self):
        frame = fixture()
        result = Pipeline().process(frame, DEFAULT_SETTINGS)
        decoded = np.frombuffer(base64.b64decode(result["iq_base64"]), dtype="<i2").reshape(2, 64, 512, 2)
        np.testing.assert_array_equal(decoded, unpack_iq(frame))
        self.assertEqual(tuple(decoded[0, 0, 0]), (4000, -1500))

    def test_reference_cancels_static_and_clears_on_config_change(self):
        frame = fixture(slow_bin=0)
        pipeline = Pipeline()
        pipeline.set_reference(frame)
        result = pipeline.process(frame, DEFAULT_SETTINGS)
        self.assertLess(np.max(result["products"]["spectrum"]["db"]), -100)
        self.assertEqual(result["reference_frame"], 7)
        changed = dict(frame, config_sha256="cd" * 32)
        self.assertIsNone(pipeline.process(changed, DEFAULT_SETTINGS)["reference_frame"])

    def test_static_rejection_only_affects_doppler(self):
        pipeline = Pipeline()
        frame = fixture(slow_bin=0)
        removed = pipeline.process(frame, DEFAULT_SETTINGS)
        kept = pipeline.process(frame, dict(DEFAULT_SETTINGS, remove_static=False))
        self.assertLess(np.max(removed["products"]["doppler"]["db"]), -100)
        self.assertGreater(np.max(kept["products"]["doppler"]["db"]), 59)
        self.assertEqual(kept["products"]["spectrum"], removed["products"]["spectrum"])

    def test_stage_failure_is_visible_and_other_products_survive(self):
        pipeline = Pipeline()
        def fail(_):
            raise ValueError("deliberate test failure")
        pipeline.stages["experimental"] = fail
        result = pipeline.process(fixture(), DEFAULT_SETTINGS)
        self.assertIn("spectrum", result["products"])
        self.assertEqual(result["stage_errors"], {"experimental": "deliberate test failure"})

    def test_settings_reject_unexpected_or_wrong_types(self):
        for settings in ({}, dict(DEFAULT_SETTINGS, remove_dc=1), dict(DEFAULT_SETTINGS, window="bad")):
            with self.assertRaises(ValueError):
                Pipeline().process(fixture(), settings)


class AcquisitionTests(unittest.TestCase):
    def test_explicit_aborts_are_separate_from_invalid_frames(self):
        parser, frames = Parser(), Frames()
        messages = list(parser.feed(wire(fixture())))
        for reason in (3, 6, 5, 99):
            for message in messages[:3]:
                frames.accept(message)
            frames.accept(Message(4, 0, 255, 65535, 3, 7, 100, 0, struct.pack("<I", reason)))
        self.assertEqual(frames.rejected, 4)
        self.assertEqual(frames.aborted, 4)
        self.assertEqual(frames.protocol_errors, 0)
        self.assertEqual(frames.abort_reasons, {3: 1, 6: 1, 5: 1, 99: 1})
        self.assertEqual(frames.last_abort["received_records"], 2)
        viewer = server.Viewer()
        viewer._update_decode(parser, frames)
        self.assertEqual(viewer.stats["queue_aborts"], 1)
        self.assertEqual(viewer.stats["cpu_aborts"], 1)
        self.assertEqual(viewer.stats["other_aborts"], 2)
        self.assertEqual(viewer.stats["invalid_frames"], 0)
        self.assertEqual(viewer.stats["device_skipped"], 2)  # No completed frame required.
        self.assertEqual(viewer.stats["device_queue_peak"], 100)

    def test_malformed_abort_is_not_counted_as_firmware_protection(self):
        parser, frames = Parser(), Frames()
        for message in list(parser.feed(wire(fixture())))[:3]:
            frames.accept(message)
        frames.accept(Message(4, 0, 255, 65535, 3, 7, 100, 0, b"bad"))
        viewer = server.Viewer()
        viewer._update_decode(parser, frames)
        self.assertEqual(viewer.stats["invalid_frames"], 1)
        self.assertEqual(viewer.stats["device_aborts"], 0)
        self.assertEqual(viewer.stats["protocol_errors"], 1)

    def test_wire_rate_remains_visible_when_all_frames_abort(self):
        viewer = server.Viewer()
        viewer.last_frame_at = time.monotonic() - 10
        viewer.rate_at = time.monotonic()
        viewer.stats.update(wire_kbps=600, frames_per_second=5)
        self.assertEqual(viewer.state()["stats"]["wire_kbps"], 600)
        self.assertEqual(viewer.state()["stats"]["frames_per_second"], 0)
        viewer.rate_at -= 3
        self.assertEqual(viewer.state()["stats"]["wire_kbps"], 0)

    def test_corrupt_frame_never_reaches_processing_and_next_frame_recovers(self):
        viewer = server.Viewer()
        chunks, frames = queue.Queue(), queue.Queue(maxsize=1)
        original = wire(fixture())
        corrupt = bytearray(original)
        corrupt[200] ^= 0x80
        chunks.put(bytes(corrupt) + original)
        thread = threading.Thread(target=viewer._decode, args=(chunks, frames))
        thread.start()
        try:
            complete = frames.get(timeout=3)
            self.assertEqual(complete["lanes"], fixture()["lanes"])
        finally:
            viewer.stop_event.set()
            thread.join(2)
        self.assertEqual(viewer.stats["complete_frames"], 1)
        self.assertEqual(viewer.stats["rejected_frames"], 1)
        self.assertGreater(viewer.stats["parser_errors"], 0)

    def test_display_backlog_keeps_latest_without_discarding_raw_integrity(self):
        viewer = server.Viewer()
        frames = queue.Queue(maxsize=1)
        viewer._publish_raw(fixture(frame_id=1), frames)
        viewer._publish_raw(fixture(frame_id=2), frames)
        self.assertEqual(frames.get()["frame_id"], 2)
        self.assertEqual(viewer.stats["complete_frames"], 2)
        self.assertEqual(viewer.stats["processing_drops"], 1)

    def test_does_not_open_uart_or_nonmatching_device(self):
        viewer = server.Viewer()
        with patch.object(server, "usb_ports", return_value=["COM30"]), patch.object(server.serial, "Serial") as serial_open:
            with self.assertRaises(ValueError):
                viewer.connect(port="COM13")
            serial_open.assert_not_called()

    def test_replay_lifecycle_and_snapshot_preserve_raw_frame(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "test.ldf"
            path.write_bytes(wire(fixture()))
            viewer = server.Viewer()
            viewer.connect(replay=path)
            try:
                deadline = time.monotonic() + 3
                while viewer.latest is None and time.monotonic() < deadline:
                    time.sleep(.02)
                self.assertIsNotNone(viewer.latest)
                with patch.object(server, "OUTPUT", Path(temp) / "output"):
                    saved = Path(viewer.snapshot())
                    meta = json.loads(next(saved.glob("frame-*/frame.json")).read_text())
                    self.assertEqual(meta["lane_sha256"][0], hashlib.sha256(fixture()["lanes"][0]).hexdigest())
                    self.assertIn("lanes", viewer.raw_frame)
            finally:
                viewer.disconnect()
            self.assertFalse(viewer.threads)
            self.assertEqual(viewer.status, "disconnected")

    def test_recording_retains_exact_bytes_with_manifest(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(server, "OUTPUT", Path(temp)):
            viewer = server.Viewer()
            viewer.status = "live"
            viewer.source = "test"
            viewer.start_recording()
            data = wire(fixture())
            class FakeSerial:
                in_waiting = 0
                def __init__(self):
                    self.sent = False
                def read(self, _):
                    if self.sent:
                        viewer.stop_event.set()
                        return b""
                    self.sent = True
                    return data
                def close(self):
                    pass
            viewer.transport = FakeSerial()
            viewer._read_usb(queue.Queue())
            folder = Path(viewer.record_result)
            self.assertEqual((folder / "stream.ldf").read_bytes(), data)
            report = json.loads((folder / "report.json").read_text())
            self.assertEqual(report["stream_sha256"], hashlib.sha256(data).hexdigest())


class HTTPTests(unittest.TestCase):
    def test_local_control_requires_token_and_matching_origin(self):
        viewer = server.Viewer()
        httpd = server.ThreadingHTTPServer(("127.0.0.1", 0), server.make_handler(viewer, "test-token"))
        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        connection = http.client.HTTPConnection("127.0.0.1", httpd.server_port, timeout=2)
        try:
            for headers in ({}, {"X-Viewer-Token": "test-token", "Origin": "https://example.org"}):
                connection.request("POST", "/api/settings", json.dumps(DEFAULT_SETTINGS), headers)
                response = connection.getresponse()
                self.assertEqual(response.status, 403)
                response.read()
            connection.request("POST", "/api/settings", json.dumps(DEFAULT_SETTINGS), {"X-Viewer-Token": "test-token"})
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            response.read()
            connection.request("GET", "/../server.py")
            response = connection.getresponse()
            self.assertEqual(response.status, 404)
            response.read()
        finally:
            connection.close()
            httpd.shutdown()
            httpd.server_close()
            thread.join()


if __name__ == "__main__":
    unittest.main()
