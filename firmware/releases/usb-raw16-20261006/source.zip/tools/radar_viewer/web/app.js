'use strict';
const $ = id => document.getElementById(id);
let token = '', version = -1, generation = -1, current = null, iq = null;
let history = [], paused = false, recording = false, busy = false, messageUntil = 0;
const colors = ['#55e0d4', '#ee85b0', '#f6b86b', '#ad9fff'];
const fmt = n => Number(n || 0).toLocaleString();

function notice(text, error=false, persistent=false) {
  $('notice').textContent = text; $('notice').hidden = !text;
  $('notice').className = error ? 'error' : '';
  messageUntil = persistent ? Infinity : Date.now() + 8000;
}
async function request(path, body) {
  const response = await fetch('/api/' + path, {method:'POST',
    headers:{'Content-Type':'application/json','X-Viewer-Token':token},body:JSON.stringify(body || {})});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || response.statusText);
  return data;
}
function action(id, callback) {
  $(id).addEventListener('click', async () => {
    if (busy) return;
    busy = true; $(id).disabled = true;
    try { await callback(); } catch (err) { notice(err.message, true); }
    finally { busy = false; $(id).disabled = false; }
  });
}
async function options() {
  const response = await fetch('/api/options');
  if (!response.ok) throw new Error('Cannot load viewer options');
  const data = await response.json(); token = data.token;
  const port = $('port').value, replay = $('replay').value;
  $('port').replaceChildren(...(data.ports.length ? data.ports : ['No matching USB device']).map(p => new Option(p,p)));
  if (data.ports.includes(port)) $('port').value = port;
  $('replay').replaceChildren(...data.sources.map(s => new Option(s.name.replace('output\\stream_bench\\','').replace('\\stream.ldf',''),s.id)));
  if (data.sources.some(s => s.id === replay)) $('replay').value = replay;
  else { const preferred = data.sources.find(s => s.name.includes('usb_budget_guard_capture')); if (preferred) $('replay').value = preferred.id; }
}
action('refresh', options);
action('connect', async () => { await request('connect',{port:$('port').value}); resetDisplay(); notice('USB acquisition started.'); });
action('disconnect', async () => { await request('disconnect'); notice('Disconnected. The USB port is released.'); });
action('play', async () => { await request('replay',{id:$('replay').value}); resetDisplay(); notice('Replay started. Recordings loop automatically.'); });
action('reference', async () => { await request('reference',{enabled:true}); notice('Background captured from the latest acquired frame.'); });
action('clear-reference', async () => { await request('reference',{enabled:false}); notice('Background cleared.'); });
action('record', async () => { await request(recording?'record/stop':'record/start'); await options(); });
action('snapshot', async () => { const data = await request('snapshot'); notice('Saved latest acquired frame: ' + data.path); });
function resetDisplay() { version=-1; current=iq=null; history=[]; paused=false; $('pause').textContent='Freeze display'; $('pause').classList.remove('active'); acceptFrame(null); }
$('pause').addEventListener('click', () => {
  paused = !paused; $('pause').textContent = paused ? 'Resume display' : 'Freeze display'; $('pause').classList.toggle('active',paused);
  if (!paused) { version=-1; history=[]; }
  notice(paused ? 'Display frozen. USB acquisition and recording continue; chirp selection still works.' : 'Display resumed; history starts fresh.');
});
for (const id of ['remove_dc','window','remove_static']) $(id).addEventListener('change', async () => {
  try { await request('settings',{remove_dc:$('remove_dc').checked,window:$('window').value,remove_static:$('remove_static').checked}); }
  catch (err) { notice(err.message,true); }
});
for (const id of ['receiver','chirp','mean','color-min','color-max']) $(id).addEventListener('input', draw);
new ResizeObserver(() => draw()).observe(document.querySelector('main'));

function setup(id, margins={l:48,r:12,t:12,b:29}) {
  const canvas = $(id), rect = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  const width = Math.max(1,Math.round(rect.width*dpr)), height=Math.max(1,Math.round(rect.height*dpr));
  if (canvas.width!==width || canvas.height!==height) {canvas.width=width;canvas.height=height;}
  const ctx=canvas.getContext('2d'); ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,rect.width,rect.height);
  ctx.font='10px system-ui';
  return {ctx,w:rect.width,h:rect.height,x:margins.l,y:margins.t,pw:Math.max(1,rect.width-margins.l-margins.r),ph:Math.max(1,rect.height-margins.t-margins.b)};
}
function axes(p,xmin,xmax,ymin,ymax,xTicks,yTicks,grid=true) {
  const {ctx,x,y,pw,ph}=p;
  ctx.strokeStyle='#28364a';ctx.fillStyle='#8195af';ctx.lineWidth=1;
  ctx.textAlign='center';ctx.textBaseline='top';
  for(const val of xTicks){const xx=x+(val-xmin)/(xmax-xmin)*pw; if(grid){ctx.beginPath();ctx.moveTo(xx,y);ctx.lineTo(xx,y+ph);ctx.stroke();}ctx.fillText(String(val),xx,y+ph+8);}
  ctx.textAlign='right';ctx.textBaseline='middle';
  for(const val of yTicks){const yy=y+ph-(val-ymin)/(ymax-ymin)*ph;if(grid){ctx.beginPath();ctx.moveTo(x,yy);ctx.lineTo(x+pw,yy);ctx.stroke();}ctx.fillText(String(val),x-7,yy);}
  ctx.strokeStyle='#40516a';ctx.strokeRect(x,y,pw,ph);
}
function line(p,values,ymin,ymax,color){
  const {ctx,x,y,pw,ph}=p;ctx.save();ctx.beginPath();ctx.rect(x,y,pw,ph);ctx.clip();ctx.strokeStyle=color;ctx.lineWidth=1.15;ctx.beginPath();
  values.forEach((v,i)=>{const xx=x+i/(values.length-1)*pw,yy=y+ph-(v-ymin)/(ymax-ymin)*ph;i?ctx.lineTo(xx,yy):ctx.moveTo(xx,yy);});ctx.stroke();ctx.restore();
}
function empty(p){p.ctx.fillStyle='#708299';p.ctx.textAlign='center';p.ctx.fillText('Waiting for a complete frame',p.w/2,p.h/2);}
function wave(){
  const p=setup('wave');if(!iq || !current){empty(p);return;}
  const chirps=current.chirps, chirp=Number($('chirp').value), mean=$('mean').checked, traces=[];
  $('chirp-label').textContent=mean?'mean':chirp; $('chirp').disabled=mean;
  for(let rx=0;rx<2;rx++)for(let part=0;part<2;part++){
    const values=new Float32Array(512);
    for(let n=0;n<512;n++){if(mean){for(let c=0;c<chirps;c++)values[n]+=iq[((rx*chirps+c)*512+n)*2+part]/chirps;}else values[n]=iq[((rx*chirps+chirp)*512+n)*2+part];}
    if(current.settings.remove_dc){const offset=values.reduce((a,b)=>a+b,0)/512;for(let n=0;n<512;n++)values[n]-=offset;}
    traces.push(values);
  }
  let lo=Infinity,hi=-Infinity;for(const values of traces)for(const v of values){lo=Math.min(lo,v);hi=Math.max(hi,v);}
  const span=Math.max(hi-lo,10),step=Math.pow(10,Math.floor(Math.log10(span/4))),ymin=Math.floor((lo-span*.08)/step)*step,ymax=Math.ceil((hi+span*.08)/step)*step;
  const ticks=Array.from({length:5},(_,i)=>Math.round(ymin+(ymax-ymin)*i/4));
  axes(p,0,511,ymin,ymax,[0,128,256,384,511],ticks);traces.forEach((v,i)=>line(p,v,ymin,ymax,colors[i]));
}
function spectrum(){const p=setup('spectrum');const data=current?.products.spectrum;if(!data){empty(p);return;}axes(p,-256,255,-60,90,[-256,-128,0,128,255],[-60,-30,0,30,60,90]);data.db.forEach((v,i)=>line(p,v,-60,90,colors[i*2]));}
const stops=[[16,24,45],[35,69,108],[36,143,158],[99,214,178],[239,225,139],[255,151,102]];
function heatColor(v,min,max){const t=Math.max(0,Math.min(.99999,(v-min)/(max-min)))*(stops.length-1),i=Math.floor(t),f=t-i;return stops[i].map((a,c)=>Math.round(a+(stops[i+1][c]-a)*f));}
function heat(p,rows){
  if(!rows.length)return;
  const height=rows.length,width=rows[0].length,canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
  const ctx=canvas.getContext('2d'),pixels=ctx.createImageData(width,height);
  const min=Number($('color-min').value),max=Number($('color-max').value);
  const palette=Array.from({length:256},(_,i)=>heatColor(min+(max-min)*i/255,min,max));
  for(let r=0;r<height;r++)for(let c=0;c<width;c++){const offset=(r*width+c)*4,col=palette[Math.max(0,Math.min(255,Math.round((rows[r][c]-min)/(max-min)*255)))];pixels.data[offset]=col[0];pixels.data[offset+1]=col[1];pixels.data[offset+2]=col[2];pixels.data[offset+3]=255;}
  ctx.putImageData(pixels,0,0);p.ctx.imageSmoothingEnabled=false;p.ctx.drawImage(canvas,p.x,p.y,p.pw,p.ph);
}
function waterfall(){const p=setup('waterfall');if(!history.length){empty(p);return;}const rx=Number($('receiver').value);heat(p,history.map(h=>h[rx]));axes(p,-256,255,0,history.length,[-256,-128,0,128,255],[0,Math.round(history.length/2),history.length],false);$('history-count').textContent=history.length+' displayed frames · age in rows';}
function doppler(){const p=setup('doppler');const data=current?.products.doppler;if(!data){empty(p);return;}const rx=Number($('receiver').value);heat(p,[...data.db[rx]].reverse());const ymin=data.hz[0],ymax=data.hz.at(-1),bound=Math.floor(Math.min(-ymin,ymax)/100)*100;axes(p,-64,64,ymin,ymax,[-64,-32,0,32,64],[-bound,-bound/2,0,bound/2,bound],false);const quality=current.products.quality;$('doppler-detail').textContent=quality?`${quality.chirp_interval_us} µs / chirp · ${(1e6/quality.chirp_interval_us/current.chirps).toFixed(1)} Hz / bin${quality.timing_outliers?' · timing outliers':''}`:'';}
function draw(){
  $('color-min-value').textContent=$('color-min').value+' dB';$('color-max-value').textContent=$('color-max').value+' dB';
  document.querySelectorAll('.rx-label').forEach(e=>e.textContent='RX'+(Number($('receiver').value)+1));
  wave();spectrum();waterfall();doppler();
}
function acceptFrame(frame){
  current=frame;if(!frame){iq=null;$('frame-id').textContent='—';$('frame-detail').textContent='Waiting for capture dimensions';$('residual').textContent='—';$('config').textContent='Configuration identity: waiting';$('history-count').textContent='0 displayed frames';$('doppler-detail').textContent='Waiting for timing';draw();return;}
  $('chirp').max=frame.chirps-1; $('chirp').value=Math.min(Number($('chirp').value),frame.chirps-1);
  $('mean-label').textContent='Mean of '+frame.chirps; $('doppler-tag').textContent=frame.chirps+' CHIRP FFT';
  const bytes=Uint8Array.from(atob(frame.iq_base64),c=>c.charCodeAt(0));
  // Explicit little-endian interpretation also works on a big-endian browser host.
  const view=new DataView(bytes.buffer);iq=new Int16Array(bytes.length/2);for(let i=0;i<iq.length;i++)iq[i]=view.getInt16(i*2,true);
  if(frame.products.spectrum){history.push(frame.products.spectrum.db);if(history.length>160)history.shift();}
  $('frame-id').textContent=fmt(frame.frame_id);
  $('frame-detail').textContent=`${frame.chirps} chirps / RX - ${frame.processing_ms.toFixed(1)} ms DSP`;
  const quality=frame.products.quality;
  $('residual').textContent=quality?quality.residual_percent.map(v=>v.toFixed(1)+'%').join(' / '):'—';
  $('config').textContent='Configuration: '+frame.config_sha256;
  draw();
}
function updateState(state){
  const s=state.stats,stale=state.last_frame_age_s===null || state.last_frame_age_s>2;
  const limited=stale && state.last_abort_age_s!==null && state.last_abort_age_s<3;
  $('status').textContent=state.status==='live'?(limited?'LIVE · EXPORT LIMITED':stale?'LIVE · WAITING':'LIVE · USB'):state.status.toUpperCase();
  $('status').className='badge '+(state.status==='error'?'error':stale&&state.status==='live'?'warn':state.status);
  $('source').textContent=state.source || 'Waiting for a source';
  $('rate').textContent=Number(s.wire_kbps).toFixed(0);$('fps').textContent=Number(s.frames_per_second).toFixed(1);
  $('frames').textContent=fmt(s.complete_frames)+' total complete frames';
  for(const [id,key] of Object.entries({'parser-errors':'parser_errors','protocol-errors':'protocol_errors',rejected:'rejected_frames',resync:'discarded_bytes','device-skips':'device_skipped','device-rejects':'device_rejected','queue-aborts':'queue_aborts','cpu-aborts':'cpu_aborts','other-aborts':'other_aborts','invalid-frames':'invalid_frames',drops:'processing_drops',timing:'timing_outliers'}))$(id).textContent=fmt(s[key]);
  const reasons={1:'prior frame incomplete',2:'invalid radar record or sequence',3:'output buffer full',4:'timeout',5:'acquisition or USB gap',6:'CPU backlog guard'};
  $('abort-detail').textContent=s.last_abort?`Last device abort: ${reasons[s.last_abort.reason] || 'reason '+s.last_abort.reason} · frame ${fmt(s.last_abort.frame_id)} · ${s.last_abort.received_records}/${s.last_abort.expected_records} records arrived. This candidate is not displayed.`:'No firmware abort observed in this connection.';
  $('health-summary').textContent=`${state.last_frame_age_s===null?'No frame yet':'Last processed frame '+state.last_frame_age_s.toFixed(1)+' s ago'} · ${fmt(s.received_bytes)} wire bytes · ${s.replay_loops} replay loops${s.truncated_tail?' · partial recording tail discarded':''}${paused?' · display frozen':''}`;
  recording=!!state.recording;$('record').textContent=recording?'Stop recording':'Start raw recording';$('record').classList.toggle('active',recording);
  $('record-state').textContent=recording?`${(state.recording.bytes/1e6).toFixed(1)} MB recorded · ${state.recording.path}`:state.last_recording?'Saved: '+state.last_recording:'Original USB bytes and SHA-256 manifest. Recording stops automatically at 1 GiB.';
  $('reference-state').textContent=state.reference_frame===null?'No background reference. Subtraction affects spectrum and Doppler.':'Background: frame '+state.reference_frame+'. Applied to spectrum and Doppler.';
  if(!busy && document.activeElement!==$('window')){
    $('remove_dc').checked=state.settings.remove_dc;$('window').value=state.settings.window;$('remove_static').checked=state.settings.remove_static;
  }
  if(state.error) notice(state.error,true,true);
  else if(state.frame && Object.keys(state.frame.stage_errors).length)notice('Processing stage error: '+JSON.stringify(state.frame.stage_errors),true,true);
  else if(Date.now()>messageUntil)$('notice').hidden=true;
  if(!paused){
    if(generation!==state.generation){history=[];generation=state.generation;}
    if(Object.hasOwn(state,'frame') && (!state.frame || state.frame.generation===state.generation))acceptFrame(state.frame);
  }
  version=state.version;
}
async function poll(){
  try {const response=await fetch('/api/state?since='+version);if(!response.ok)throw new Error('Viewer server returned '+response.status);updateState(await response.json());}
  catch(err){$('status').textContent='SERVER OFFLINE';$('status').className='badge error';notice(err.message,true);}
  setTimeout(poll,180);
}
options().then(poll).catch(err=>{notice(err.message,true);setTimeout(()=>location.reload(),3000);});
